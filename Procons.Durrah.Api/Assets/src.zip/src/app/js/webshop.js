(function($) {

  'use strict';


})(jQuery);
